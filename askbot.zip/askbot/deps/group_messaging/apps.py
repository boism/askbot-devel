class AskbotConfig(AppConfig):
    name = 'AskbotMessaging'
    verbose_name = 'Askbot Messaging'
