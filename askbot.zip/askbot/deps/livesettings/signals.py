import django.dispatch

configuration_value_changed = django.dispatch.Signal()
