class OAuthError(Exception):
    """Error raised by the OAuthConnection class
    """
    pass


