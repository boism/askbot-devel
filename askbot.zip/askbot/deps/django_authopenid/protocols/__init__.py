"""Module to hold supported Authentication protocols"""
