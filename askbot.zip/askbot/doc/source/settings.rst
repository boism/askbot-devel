=================================
Settings for ``settings.py`` file
=================================

* ``ALLOW_UNICODE_SLUGS`` - if ``True``, slugs will use unicode, default - ``False``

There are more settings that are not documented yet,
but most are described in the ``settings.py`` template:

    askbot/setup_templates/settings.py.mustache

TODO: describe all of them here.


