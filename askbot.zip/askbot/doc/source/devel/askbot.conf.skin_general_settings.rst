.. _askbot.conf.skin_general_settings:

:mod:`askbot.conf.skin_general_settings`
=================================

.. automodule:: askbot.conf.skin_general_settings
    :members:
    :undoc-members:
    :show-inheritance:

