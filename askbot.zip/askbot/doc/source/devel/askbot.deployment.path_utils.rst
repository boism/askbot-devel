.. _askbot.deployment.path_utils:

:mod:`askbot.deployment.path_utils`
============================

.. automodule:: askbot.deployment.path_utils
    :members:
    :undoc-members:
    :show-inheritance:

