.. _askbot.templatetags.extra_tags:

:mod:`askbot.templatetags.extra_tags`
==============================

.. automodule:: askbot.templatetags.extra_tags
    :members:
    :undoc-members:
    :show-inheritance:

