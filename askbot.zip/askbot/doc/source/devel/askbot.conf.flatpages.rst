.. _askbot.conf.flatpages:

:mod:`askbot.conf.flatpages`
=====================

.. automodule:: askbot.conf.flatpages
    :members:
    :undoc-members:
    :show-inheritance:

