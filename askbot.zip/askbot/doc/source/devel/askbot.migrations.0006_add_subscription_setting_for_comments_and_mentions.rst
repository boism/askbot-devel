.. _askbot.migrations.0006_add_subscription_setting_for_comments_and_mentions:

:mod:`askbot.migrations.0006_add_subscription_setting_for_comments_and_mentions`
=========================================================================

.. automodule:: askbot.migrations.0006_add_subscription_setting_for_comments_and_mentions
    :members:
    :undoc-members:
    :show-inheritance:

