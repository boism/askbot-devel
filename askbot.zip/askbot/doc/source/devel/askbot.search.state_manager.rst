.. _askbot.search.state_manager:

:mod:`askbot.search.state_manager`
===========================

.. automodule:: askbot.search.state_manager
    :members:
    :undoc-members:
    :show-inheritance:

