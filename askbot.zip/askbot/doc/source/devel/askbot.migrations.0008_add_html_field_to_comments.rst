.. _askbot.migrations.0008_add_html_field_to_comments:

:mod:`askbot.migrations.0008_add_html_field_to_comments`
=================================================

.. automodule:: askbot.migrations.0008_add_html_field_to_comments
    :members:
    :undoc-members:
    :show-inheritance:

