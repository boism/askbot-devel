.. _askbot.conf.email:

:mod:`askbot.conf.email`
=================

.. automodule:: askbot.conf.email
    :members:
    :undoc-members:
    :show-inheritance:

