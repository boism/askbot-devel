.. _askbot.templatetags:

:mod:`askbot.templatetags`
===================

.. automodule:: askbot.templatetags
    :members:
    :undoc-members:
    :show-inheritance:

.. _modules::

:mod:`Modules`
-------


* :ref:`askbot.templatetags.extra_filters`
* :ref:`askbot.templatetags.extra_tags`
* :ref:`askbot.templatetags.smart_if`

