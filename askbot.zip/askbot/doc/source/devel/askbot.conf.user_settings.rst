.. _askbot.conf.user_settings:

:mod:`askbot.conf.user_settings`
=========================

.. automodule:: askbot.conf.user_settings
    :members:
    :undoc-members:
    :show-inheritance:

