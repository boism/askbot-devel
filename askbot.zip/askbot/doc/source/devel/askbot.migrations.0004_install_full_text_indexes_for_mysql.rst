.. _askbot.migrations.0004_install_full_text_indexes_for_mysql:

:mod:`askbot.migrations.0004_install_full_text_indexes_for_mysql`
==========================================================

.. automodule:: askbot.migrations.0004_install_full_text_indexes_for_mysql
    :members:
    :undoc-members:
    :show-inheritance:

