.. _askbot.setup_templates.urls:

:mod:`askbot.setup_templates.urls`
===========================

.. automodule:: askbot.setup_templates.urls
    :members:
    :undoc-members:
    :show-inheritance:

