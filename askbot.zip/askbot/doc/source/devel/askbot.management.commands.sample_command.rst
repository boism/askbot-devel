.. _askbot.management.commands.sample_command:

:mod:`askbot.management.commands.sample_command`
=========================================

.. automodule:: askbot.management.commands.sample_command
    :members:
    :undoc-members:
    :show-inheritance:

