.. _askbot.conf.minimum_reputation:

:mod:`askbot.conf.minimum_reputation`
==============================

.. automodule:: askbot.conf.minimum_reputation
    :members:
    :undoc-members:
    :show-inheritance:

