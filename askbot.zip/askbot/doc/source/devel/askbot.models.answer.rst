.. _askbot.models.answer:

:mod:`askbot.models.answer`
====================

.. automodule:: askbot.models.answer
    :members:
    :undoc-members:
    :show-inheritance:

