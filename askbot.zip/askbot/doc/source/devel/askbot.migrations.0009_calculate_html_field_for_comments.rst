.. _askbot.migrations.0009_calculate_html_field_for_comments:

:mod:`askbot.migrations.0009_calculate_html_field_for_comments`
========================================================

.. automodule:: askbot.migrations.0009_calculate_html_field_for_comments
    :members:
    :undoc-members:
    :show-inheritance:

