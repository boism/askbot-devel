.. _about:
========================
Basic facts about Askbot
========================

* Askbot is Question and Answer (Q&A) forum.
* Open source GPL3 license
* Written in Python using Django framework

