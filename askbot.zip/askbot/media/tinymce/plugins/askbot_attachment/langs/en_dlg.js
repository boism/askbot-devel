tinyMCE.addI18n('en.askbot_imageupload_dlg',{
	title : 'Upload an image'
});
