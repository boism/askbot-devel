tinyMCE.addI18n('en.askbot_imageupload',{
	desc : 'Upload an image'
});
