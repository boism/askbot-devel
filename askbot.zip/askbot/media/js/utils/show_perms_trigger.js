var ShowPermsTrigger = function () {
    HoverCardTrigger.call(this);
    this._hoverCardClass = PermsHoverCard;
};
inherits(ShowPermsTrigger, HoverCardTrigger);
