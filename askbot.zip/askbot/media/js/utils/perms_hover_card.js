var PermsHoverCard = function () {
    HoverCard.call(this);
};
inherits(PermsHoverCard, HoverCard);

PermsHoverCard.prototype.setContent = function (data) {
    //content of PermsHoverCard is rendered by the server
    this._element.html(data.html);
};
