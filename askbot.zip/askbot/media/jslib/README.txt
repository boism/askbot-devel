3rd party js libraries, plugins
and utilities.


Some files have been modified for Askbot,
so it cannot be assumed that files can
be simply upgraded.

Files/directories known to be modified:
wmd (added django i18n)
tinymce (custom plugins file and attachement uploads)
timeago.js added django i18n, possibly modified some
           output formats
